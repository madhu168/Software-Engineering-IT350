# NITK_Night_Canteen_Management
Canteen Management System 
