from django.apps import AppConfig


class CanteensConfig(AppConfig):
    name = 'canteens'
