from django.contrib import admin
from django.urls import path
from django.conf.urls import url,include
from . import views
from django.views.generic.base import TemplateView
from . import views, settings
from django.contrib.staticfiles.urls import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns



urlpatterns = [
	url(r'^$',views.home_redirect,name='home_redirect'),
    path('admin/', admin.site.urls),
    url(r'^account/',include('accounts.urls')),
    url(r'^canteen/',include('canteens.urls')),
    url(r'^about-us/$',TemplateView.as_view(template_name = "canteens/index.html"), name="aboutus"),

]

urlpatterns += staticfiles_urlpatterns()
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)